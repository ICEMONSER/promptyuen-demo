import test from 'node:test';
import assert from 'node:assert/strict';
import {validThaiId,parseLicenseQR} from '../assets/import-document.js';
import {renderReport,thaiDate} from '../assets/report.js';
import {haversine,rankStations,nearestStations,findDistrict} from '../assets/station-core.js';
import {selectDocuments,checklist} from '../assets/case-config.js';
import {rebuildCases} from '../assets/store.js';
import {validateAnalysis,analyzePhoto} from '../assets/vision.js';
test('Buddhist dates, escaping and A4 print rules',()=>{
  assert.match(thaiDate('2026-10-01'),/2569/);assert.match(thaiDate('2569-10-01'),/2569/);
  const output=renderReport({service:'police',fields:{fullName:{value:'<script>alert(1)</script>'}}},{short:'แจ้งความ',label:'แจ้งความ',agency:'ตำรวจ',note:'ร่าง'},{});
  assert.match(output,/@page\{size:A4/);assert.match(output,/&lt;script&gt;/);assert.ok(!output.includes('<script>alert'));
});
test('Thai ID checksum including Thai digits and unsupported QR',()=>{
  assert.equal(validThaiId('1234567890121'),true);assert.equal(validThaiId('๑๒๓๔๕๖๗๘๙๐๑๒๑'),true);
  for(const id of ['1234567890120','0000000000000','DEMO','123'])assert.equal(validThaiId(id),false);
  assert.equal(parseLicenseQR('{"name":"ตัวอย่าง","licenseNumber":"TEST"}').fields.licenseNumber,'TEST');
  assert.equal(Object.keys(parseLicenseQR('https://example.com/opaque').fields).length,0);
});
test('Haversine sorting and Overpass node/way parsing',()=>{
  assert.equal(haversine({lat:0,lon:0},{lat:0,lon:0}),0);
  assert.ok(Math.abs(haversine({lat:0,lon:0},{lat:0,lon:1})-111.195)<.01);
  const rows=[3,1,2,4].map(n=>({type:'way',id:n,center:{lat:n*.01,lon:0},tags:{'name:th':`สถานี ${n}`}}));
  assert.deepEqual(rankStations(rows,{lat:0,lon:0}).map(r=>r.id),['way/1','way/2','way/3']);
});
test('Station query, empty results and network failures',async()=>{
  const original=globalThis.fetch;
  try {
    globalThis.fetch=async(url,options)=>{assert.match(String(options.body),/amenity/);return {ok:true,json:async()=>({elements:[]})};};
    await assert.rejects(nearestStations({lat:13,lon:100}),/ไม่พบสถานี/);
    globalThis.fetch=async()=>{throw new Error('offline');};
    await assert.rejects(findDistrict('กรุงเทพมหานคร','ปทุมวัน'),/ค้นหาสถานีไม่สำเร็จ/);
    await assert.rejects(nearestStations({lat:NaN,lon:100}),/ตรวจละติจูด/);
  } finally{globalThis.fetch=original;}
});
test('Checklist selection, replacement and deletion refresh case references',()=>{
  const docs=[{id:'identity',kind:'identity',verified:true},{id:'vehicle',kind:'vehicle',verified:false}];
  assert.deepEqual(selectDocuments('accident',docs),['identity']);
  assert.equal(checklist('accident',docs,[]).filter(item=>item.selected).length,0);
  const cases=[{fields:{fullName:{documentId:'identity',value:'เดิม'}}}];
  assert.equal(rebuildCases(cases,{identity:{...docs[0],fields:{fullName:'ใหม่'}}})[0].fields.fullName.value,'ใหม่');
  assert.equal(rebuildCases(cases,{})[0].fields.fullName.value,'');
});
test('Vision schema rejects invalid severity, confidence and non-Thai text',async()=>{
  const good={part:'กันชนหน้า',severity:2,summary_th:'เห็นรอยบุบจากภาพ',confidence:.6};assert.deepEqual(validateAnalysis(good),good);
  for(const patch of [{severity:4},{severity:'2'},{confidence:NaN},{summary_th:'English'},{part:'front'}])assert.throws(()=>validateAnalysis({...good,...patch}));
  await assert.rejects(analyzePhoto(''),/ยังไม่ได้ตั้งค่า AI/);
});
